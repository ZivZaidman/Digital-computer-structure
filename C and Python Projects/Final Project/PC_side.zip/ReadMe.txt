GUI.py - a python file that controls the FSM run by the msp430 and the C files we wrote on the CCS. the GUI.py runs a Graphical User Interface that helps control the FSM.
main.c - includes the main FSM states.
appi.c - includes the application functions on the high level.
halGPIO.c - includes the hal function, in the lower level.
Flash.c - includes FLASH functions.
bsp.c - includes the initialitions of the FSM machine
Header files - includes external Funcs and variables.