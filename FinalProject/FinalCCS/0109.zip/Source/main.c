#include  "../header/api.h"         // private library - API layer
#include  "../header/app.h"         // private library - APP layer

enum FSMstate state;
enum Motorstate stepState;
enum SYSmode lpm_mode;
int input_slot=0;
char input[80]={0};
char Rec_data[80]={0};
int Vy_Vx[2]={0};
char Test[5]={0};
int ack=0;
int d=50;
int file_uploaded_ind=0;
int file_execute_ind=0;



void main(void){


     state = Idle;
     stepState = Idlestep;
     lpm_mode = mode0;     // start in idle state on RESET
     sysConfig();     // Configure GPIO, Init ADC
     lcd_init();
     lcd_clear();
     //dec_lcd(10);
     /*while (1){
         //inc_lcd(20);
         //dec_lcd(25);
         rra_lcd('X');
         //lcd_puts('x',1);
         //lcd_display_shift();
         TIMERA0_delay_ms(0xFFFF);
     }*/




     while (1){
         switch(state){
          case Idle:
              lcd_clear();
              //stepper_deg(180);
              //stepper_scan(270,90);
              __bis_SR_register(LPM0_bits + GIE);       // wait for command from SW
              break;
          case calibration: //stepmotor calibration
              IE2 |= UCA0RXIE; // Enable USCI_A0 RX interrupt
              clibrateMotor();
              break;
          case JoystickRotation:
              IE2 |= UCA0RXIE; // Enable USCI_A0 RX interrupt
              Joystickcontroledangle();
              break;
          case Painter:
               IE2 |= UCA0RXIE;
               joystick_painter();
               break;
          case Script:
              IE2 |= UCA0RXIE; // Enable USCI_A0 RX interrupt
              Script_mode();
              }

         }

}
