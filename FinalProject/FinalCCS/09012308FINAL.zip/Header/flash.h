#ifndef HEADER_MEMORY_MANAGER_H_
#define HEADER_MEMORY_MANAGER_H_

#include <msp430g2553.h>  // Include MSP430 microcontroller header

// Function declarations for memory management
extern void update_current_file_size(void);
extern void initialize_file_pointer(void);
extern void write_data_to_flash(void);
extern int rotationCounter;
extern int CalibAngles;

// Structure to manage file metadata in flash memory
typedef struct MemoryFiles {
    short total_files;               // Number of files stored
    char file_names[11];             // Names of files (up to 11 characters)
    int* file_pointers[3];           // Pointers to file start addresses in flash
    int file_sizes[3];               // Sizes of files in bytes
} MemoryFiles;

// Global variable declaration
extern MemoryFiles memoryFiles;

#endif // HEADER_MEMORY_MANAGER_H_
