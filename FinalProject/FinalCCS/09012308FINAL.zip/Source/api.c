#include  "../header/api.h"         // private library - API layer
#include  "../header/halGPIO.h"     // private library - HAL layer
#include "stdio.h"

enum Motorstate stepState;
int angle=0;
int32_t temp_division=0;
unsigned int amount_of_steps =0;
int CalibAngles=0;
int clockDIR=0;
char printarray[5]={0};
char rotations[5]={0};
char angles[5]={0};
int prevP=0;
int Vrx=0;
int Vry=0;
unsigned int iter=0;
unsigned int iter2=0;
int rotationscounterScript=0;
int ScriptAngles=0;
int Tx_index=0;
int degreeORscan=0;
//==================================================================================
//========================calibrate stepmotor======================================//
void clibrateMotor(){
    IE2 &= ~UCA0TXIE; // disable USCI_A0 TX interrupt to stop further transmissions
    switch (stepState){//check motor state
    int j=0;
    int i;
      case Idlestep:
          __bis_SR_register(LPM0_bits + GIE);       // wait for command from SW
          break;
      case Rotate:
          rotationCounter=0;
          while(rotateFlag){ //rotateflag state whether its on rotate or not
              rotationCounter++;
              clockwiseRotation();
              TIMERA0_delay_ms(1000);
          }
          break;
      case StopRotate://stop rotation in motor
          //-----------------send number of rotations-----------
          if (state==calibration){
              for (j=0;j<5;j++){//reset rotation list
                  rotations[j]=0;
                }
              inttochar(rotations, (int)rotationCounter);//int to list of char- number of rotations
              for (i=0;i<5;i++){            //send char number of rotaions to PC
                  IE2 &= ~UCA0TXIE;
                  __bic_SR_register(GIE);
                  while (!(UCA0TXIFG)){//check if TX busy
                    asm("nop");
                }
                  UCA0TXBUF=(rotations[i]); //send byte
                  IE2 |= UCA0TXIE; // enable USCI_A0 TX interrupt to stop further transmissions
                  __bis_SR_register(LPM0_bits+GIE);//wait for interrupt from TX- state end of sending data
              }
              //=================send angle======
              CalibAngles=divisionBy128(rotationCounter*90);//calculate angle from number of rotations by shifter
              for (j=0;j<5;j++){ //reset angles list
                    angles[j]=0;
              }                              //make sure that angles[5] is clear
              inttochar (angles,CalibAngles);// int to list of char -angles of rotations
              for (i=0;i<5;i++){            //send char angles
                    IE2 &= ~UCA0TXIE;
                    __bic_SR_register(GIE);
                    while (!(UCA0TXIFG)){
                      asm("nop");
                  }
                    UCA0TXBUF=(angles[i]);
                    IE2 |= UCA0TXIE; // enable USCI_A0 TX interrupt to stop further transmissions
                    __bis_SR_register(LPM0_bits+GIE);
                }

              write_calib_data(); //save data in FLASH
          }
          prevP=0; //reset prevP
          break;
    }
    if (state==JoystickRotation){
        return;
    }
}
//-------------------change angle according to joystick-----------------//
void Joystickcontroledangle(){
    clibrateMotor();
    TIMERA0_delay_ms(0xFFFF);
    TIMERA0_delay_ms(0xFFFF);
    TIMERA0_delay_ms(0xFFFF);
    TIMERA0_delay_ms(0xFFFF);
    MessurejoystickV ();//calculates the position of X and Y

    if(((Vy_Vx[1]>=400)&& (Vy_Vx[1]<=600) && (Vy_Vx[0]>=400) && (Vy_Vx[0]<=600))){//if joystick in static mode-dont move and get another sample
        return;
    }
    int Vrx = -(Vy_Vx[1] - 512);
    int Vry = -(Vy_Vx[0] - 512);
    angle= tangens(Vry,Vrx);//calculates angle
    amount_of_steps =divisionBy128(angle*182);//(angle*512)/360=Number of steps=~(angle*182)/128
    if (amount_of_steps>=256){
        amount_of_steps = 512-amount_of_steps;
        clockDIR = 1; //counter clockwise
    }
    int i;
    for (i=0;i<amount_of_steps;i++){
        if (clockDIR == 1){
            counterclockwiseRotation();
            TIMERA0_delay_ms(1000);
        }else{
            clockwiseRotation();
            TIMERA0_delay_ms(1000);
        }

    }
    clockDIR=0;//reset to clockwise
    state=Idle;//end state and go to sleep


}
//-------------------------------------------------------------
//                JoyStickADC_Steppermotor
//-------------------------------------------------------------
void MessurejoystickV (){//gets ADC samples of joystick state
    ADC10CTL0 &= ~ENC;
    while (ADC10CTL1 & ADC10BUSY);               // Wait if ADC10 core is active
    ADC10SA = &Vy_Vx;                        // Data buffer start
    ADC10CTL0 |= ENC + ADC10SC; // Sampling and conversion start
    __bis_SR_register(LPM0_bits + GIE);        // LPM0, ADC10_ISR will force exit
    ADC10CTL0 &= ~ENC;
}
//====================================================
//===================painter state====================
//=====================================================
void joystick_painter(){
    int i;
    int j;
    while(state == Painter){
        MessurejoystickV();//calcullates the position of X and Y
        if((Vy_Vx[1]>=400)&& (Vy_Vx[1]<=600) && (Vy_Vx[0]>=400) && (Vy_Vx[0]<=600)){//if joystick in static mode-dont move and get another sample
            continue;
        }
        Vrx = -(Vy_Vx[1] - 512);
        Vry = -(Vy_Vx[0] - 512);
        if ((Vrx>=-50) && (Vrx<=50)){
            Vrx=0;
        }
        if ((Vry>=-50) && (Vry<=50)){
            Vry=0;
        }
        angle= tangens(Vry,Vrx);
    //==================create char and send to PC===========

            for (j=0;j<5;j++){
                angles[j]=0;
                }
             inttochar(angles, (int)angle);//int to list of char-angle

    //----------------------send REQ---------------------------------

             IE2 &= ~UCA0TXIE;
              __bic_SR_register(GIE);
              while (!(UCA0TXIFG)){//busy?
                asm("nop");

              }
              UCA0TXBUF = 0x11; //REQ for sending angle to PC
              IE2 |= UCA0TXIE;
              // enable USCI_A0 TX interrupt to stop further transmissions
              __bis_SR_register(LPM0_bits+GIE);
              //ackTimerA0_ms(1000);
              while((ack==0) && (state==Painter)){
                  __bis_SR_register(LPM0_bits+GIE);}//wait for ACK
              //StopAllTimers();
              ack=0;

    //----------------------ACK recived-------------------------------
             for (i=0;i<5;i++){   //send list of char- angle
                 TIMERA0_delay_ms(0x3F00);
                 IE2 &= ~UCA0TXIE;
                 __bic_SR_register(GIE);
                 while (!(UCA0TXIFG)){
                   asm("nop");
               }
                 UCA0TXBUF=(angles[i]);
                 IE2 |= UCA0TXIE; // enable USCI_A0 TX interrupt to stop further transmissions
                 __bis_SR_register(LPM0_bits+GIE);
              }
             TIMERA0_delay_ms(0xF00);

       // }
    }
}

//===============int to str====================================
void inttochar (char A[5] ,int x){//write each digit of int to a member in the list
    int i=0;
    int num;
    int base=10000;
    while (i<5){
        if (num<base && i==0){
            base=1000;
            i++;
        }else if (num<base && i==1){
            base=100;
            i++;
        }else if (num<base && i==2){
            base=10;
            i++;
        }else if (num<base && i==3){
            base=1;
            i++;
        }else if (num<base && i==4){
            i++;
        }
        while (num>base-1){
            num-=base;
            A[i]++;
        }
    }
}
uint32_t hex_to_int(char *hex) {
    uint32_t val = 0;
    int o;
    for(o=0; o<2; o++) {
        // get current character then increment
        uint8_t byte = *hex++;
        // transform hex character to the 4bit equivalent number, using the ascii table indexes
        if (byte >= '0' && byte <= '9') byte = byte - '0';
        else if (byte >= 'a' && byte <='f') byte = byte - 'a' + 10;
        else if (byte >= 'A' && byte <='F') byte = byte - 'A' + 10;
        // shift 4 to make space for new digit, and add the 4 bits of the new digit
        val = (val << 4) | (byte & 0xF);
    }
    return val;
}
//===============================================================
//              Script Functions
//================================================================
void Script_mode(){
    while (state==Script){
        if (file_uploaded_ind==1){//for uploading file
            file_uploaded_ind=0;
            write_data_to_flash();//save file in FLASH
            //=========send ACK=========
            IE2 &= ~UCA0TXIE;
            __bic_SR_register(GIE);
            while (!(UCA0TXIFG)){//busy?
               asm("nop");
            }
            UCA0TXBUF = 0x22;//send finished uploading
            IE2 |= UCA0TXIE;
            // enable USCI_A0 TX interrupt to stop further transmissions
            __bis_SR_register(LPM0_bits+GIE);
            UCA0TXBUF = 0x00;
            //=== ACK sent ==========
        }
        if (file_execute_ind==1){ //for executing file
            file_execute_ind=0;
            execute_scripts();
            //execute_pointer

        }
    }
}

//======== execute order 66 ===================================

void execute_scripts(){
    int i=0;
    while (i<0x40 && state==Script){//while in the file
        unsigned int command = (*execute_pointer << 8) | *(execute_pointer + 1);//command from file
        iter = hex_to_int((execute_pointer+2)); //first
        iter2 = hex_to_int((execute_pointer+4)); //second
        switch (command){//find which command
            case '01':
                inc_lcd(iter);
                execute_pointer+=4;//4 byte forward
                i+=4;
                break;
            case '02':
                dec_lcd(iter);
                execute_pointer+=4;
                i+=4;
                break;
            case '03':
                rra_lcd(iter);
                execute_pointer+=4;
                i+=4;
                break;
            case '04':
                set_delay(iter);
                execute_pointer+=4;
                i+=4;
                break;
            case '05':
                clear_all_leds();
                execute_pointer+=2;
                i+=2;
                break;
            case '06':
                stepper_deg(iter);
                execute_pointer+=4;
                i+=4;
                break;
            case '07':
                stepper_scan(iter,iter2);
                execute_pointer+=6;//6 bytes forward
                i+=6;
                break;
            case '08':
                sleep();
                reset_delay();
                break;
            default:
                execute_pointer+=2;
                i+=2;
                break;
        }
    }

}
//=================== delay for script============================
void script_delay(){ //delay of d
    int temp1=d;
    while (temp1>50){
        TIMERA0_delay_ms(0xffff);
        temp1-=50;
    }
    if (temp1>0){
        TIMERA0_delay_ms(temp1);
    }
}
//===============increase LCD count============================
void inc_lcd(int x){
    int i;
    int j;

    for (i=0;i<=x;i++){
        for (j=0;j<5;j++){//reset array
            printarray[j]=0x30;
        }
        inttochar(printarray,i);
        lcd_puts(printarray,5);
        script_delay();
        lcd_cmd(0x01);
    }

}
//===============decrease LCD count============================
void dec_lcd(int x){
    int i;
    int j;

    for (i=x;i>=0;i--){
        for (j=0;j<5;j++){//reset array
            printarray[j]=0x30;
        }
        inttochar(printarray,i);
        lcd_puts(printarray,5);
        script_delay();
        lcd_cmd(0x01);
    }

}
//===============Right rotate LCD============================

void rra_lcd (char x){// lcd_cursor_right(), lcd_new_line(), lcd_data(x)
    int i;
    int j;
    for (i=0;i<32;i++){
        lcd_clear();
        if (i>15){
            lcd_cursor_16(i-16);
        }
        else{
            lcd_cursor(i);
        }
        lcd_data(x);
        script_delay();
    }
    lcd_clear();
}
//=============set & reset delay=====================//
void set_delay(int x){
    d=x;
}

void reset_delay(){
    d=50;
}

//==========Move Pointer X degrees=========//
void stepper_deg(int p){
    rotationscounterScript=0;
    int temp=p;//save for later
    p=p-prevP;//whats left to go from prevP
    if (p<0){p=360+p;}
    amount_of_steps =divisionBy128(p*182);//(p angle*512)/360=Number of steps=~(angle*182)/128
    if (amount_of_steps>=256){ //angle>180
        amount_of_steps = 512-amount_of_steps;
        clockDIR = 1;//counter clockwise
    }
    int i;
    for (i=0;i<amount_of_steps;i++){
        lcd_clear();
        if (clockDIR == 1){
            counterclockwiseRotation();
            TIMERA0_delay_ms(1000);
        }else{
            clockwiseRotation();
            TIMERA0_delay_ms(1000);
        }
        if (degreeORscan==0){ //print dynamic angle
            rotationscounterScript++;//to find current angle
            ScriptAngles=divisionBy128(rotationscounterScript*90);//calculate current angle from number of rotations
            sprintf(angles, "%d\n", ScriptAngles);//get array of chars
            if (ScriptAngles<10){
                lcd_puts(angles,1);
            }
            else if (ScriptAngles<100){
                    lcd_puts(angles,2);
            }
            else if (ScriptAngles<1000){
                lcd_puts(angles,3);
            }
        }
        /*for (i=0;i<5;i++){            //send char angle
            TIMERA0_delay_ms(0x3F00);

            IE2 &= ~UCA0TXIE;
            __bic_SR_register(GIE);
            while (!(UCA0TXIFG)){
              asm("nop");
          }

            UCA0TXBUF=(angles[i]);
            IE2 |= UCA0TXIE; // enable USCI_A0 TX interrupt to stop further transmissions
            __bis_SR_register(LPM0_bits+GIE);
         }
        TIMERA0_delay_ms(0xF00);
*/
        /*

        Tx_index = 0;
        IE2 |= UCA0TXIE; // Enable USCI_A0 TX interrupt
        TIMERA0_delay_ms(0x8fff);
    }
    int k;
    for (k=0;k<5;k++){
        angles[i]='X';
    }
    for (k=0;k<10;k++){
        Tx_index = 0;
        IE2 |= UCA0TXIE; // Enable USCI_A0 TX interrupt
        TIMERA0_delay_ms(0xffff);*/
    }
    lcd_clear();
    clockDIR=0;
    prevP=temp;//save new prevP

}
//=============== Scan L to R =====================
void stepper_scan(int L, int R){
    //prevP=0;
    degreeORscan=1;// dont show dynamic angle
    int dif=R-L;
    char L1[5]={0X30,0X30,0X30,0X30,0X30};
    char R1[5]={0X30,0X30,0X30,0X30,0X30};
    stepper_deg(L);//go to L angle
    TIMERA0_delay_ms(0xFFFF);
    TIMERA0_delay_ms(0xFFFF);
    stepper_deg(R);//go to R angle
    inttochar(R1,R);
    inttochar(L1,L);
    lcd_puts("Left deg: ",10);
    lcd_puts(L1,5);
    lcd_new_line;
    lcd_puts("right deg: ",11);
    lcd_puts(R1,5);
    degreeORscan=0;//reset to deg
}
//================= Sleep =========================
void sleep (){
    __bis_SR_register(LPM0_bits + GIE);       // wait for command from SW
}
//================== Clear LCD ====================
void clear_all_leds(){
    lcd_clear();

}
