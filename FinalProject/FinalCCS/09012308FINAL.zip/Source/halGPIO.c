#include  "../header/halGPIO.h"     // private library - HAL layer
#include "../header/flash.h"  // Include the header for memory management functions (private library)

enum FSMstate state;
enum Motorstate stepState;
enum SYSmode lpm_mode;

//Global variables:
int rotateFlag = 1;
int rotationCounter =0;
char* execute_pointer;//FLASH pointer

//--------------------------------------------------------------------
//             System Configuration
//--------------------------------------------------------------------
void sysConfig(void){
    GPIOconfig();
    ADCconfig();
    StopAllTimers();
    UARTConfig();
}

//-------------------ATAN2- Fixed point - returns degrees---------------------------
int16_t tangens(int16_t y_fp, int16_t x_fp)
{
    // Coefficients for fixed-point calculations
    int32_t coeff_1 = 45;        // Coefficient for fixed-point atan2 approximation
    int32_t coeff_1b = -56;      // Coefficient for fixed-point atan2 approximation
    int32_t coeff_1c = 11;       // Coefficient for fixed-point atan2 approximation
    int16_t coeff_2 = 135;       // Additional coefficient used for final angle calculation

    int16_t angle = 0;           // Variable to hold the computed angle

    int32_t r;                   // Temporary variable to hold intermediate result
    int32_t r3;                  // Variable to hold r^3

    int16_t y_abs_fp = y_fp;     // Absolute value of y_fp
    if (y_abs_fp < 0)
        y_abs_fp = -y_abs_fp;    // Make y_abs_fp positive if it's negative

    // Determine angle based on the quadrant of (x_fp, y_fp)
    if (y_fp == 0)
    {
        // If y_fp is zero, angle is either 0 or 180 degrees based on x_fp
        if (x_fp >= 0)
        {
            angle = 0;   // Positive x-axis
        }
        else
        {
            angle = 180; // Negative x-axis
        }
    }
    else if (x_fp >= 0)
    {
        // Case where x_fp is non-negative (Quadrants I or IV)
        r = (((int32_t)(x_fp - y_abs_fp)) << MULTIPLY_FP_RESOLUTION_BITS) /
            ((int32_t)(x_fp + y_abs_fp)); // Compute r for angle calculation

        r3 = r * r;                       // Calculate r^2
        r3 = r3 >> MULTIPLY_FP_RESOLUTION_BITS; // Adjust for fixed-point resolution
        r3 *= r;                         // Calculate r^3
        r3 = r3 >> MULTIPLY_FP_RESOLUTION_BITS; // Adjust for fixed-point resolution
        r3 *= coeff_1c;                  // Multiply by coefficient
        angle = (int16_t) (coeff_1 + ((coeff_1b * r + r3) >> MULTIPLY_FP_RESOLUTION_BITS)); // Calculate final angle
    }
    else
    {
        // Case where x_fp is negative (Quadrants II or III)
        r = (((int32_t)(x_fp + y_abs_fp)) << MULTIPLY_FP_RESOLUTION_BITS) /
            ((int32_t)(y_abs_fp - x_fp)); // Compute r for angle calculation
        r3 = r * r;                       // Calculate r^2
        r3 = r3 >> MULTIPLY_FP_RESOLUTION_BITS; // Adjust for fixed-point resolution
        r3 *= r;                         // Calculate r^3
        r3 = r3 >> MULTIPLY_FP_RESOLUTION_BITS; // Adjust for fixed-point resolution
        r3 *= coeff_1c;                  // Multiply by coefficient
        angle = coeff_2 + ((int16_t) (((coeff_1b * r + r3) >> MULTIPLY_FP_RESOLUTION_BITS))); // Calculate final angle
    }

    // Adjust angle based on the sign of y_fp
    if (y_fp < 0)
        return (360 - angle);  // Invert angle if y_fp is negative (Quadrants III or IV)
    else
        return angle;         // Return calculated angle for other cases
}
//-------------------------------------------------//
//------------------------Divisors------------------//
//-------------------------------------------------//
//------------ Divider by 128---------------------
unsigned int divisionBy128 (unsigned int dividend){
    unsigned int temp=0;
    //for (i=0;i<7;i++){
        temp=dividend>>7;
    //}
    return temp;
}

//-----------------------------------------------
//              StepMotor functions
//-----------------------------------------------
void counterclockwiseRotation(){
    StepmotorPortOUT = 0x01;
    TIMERA0_delay_ms(1000);
    StepmotorPortOUT = 0x08;
    TIMERA0_delay_ms(1000);
    StepmotorPortOUT = 0x04;
    TIMERA0_delay_ms(1000);
    StepmotorPortOUT = 0x02;
}
void clockwiseRotation(){
    StepmotorPortOUT = 0x08;
    TIMERA0_delay_ms(1000);
    StepmotorPortOUT = 0x01;
    TIMERA0_delay_ms(1000);
    StepmotorPortOUT = 0x02;
    TIMERA0_delay_ms(1000);
    StepmotorPortOUT = 0x04;
}
//-----------------------------------------------
//                   Timers
//-----------------------------------------------
//            Start Timer0 With counter
void TIMERA0_delay_ms(unsigned int counter){
    TIMER_A0_config(counter);
    __bis_SR_register(LPM0_bits + GIE);       // Enter LPM0 w/ interrupt
}
void ackTimerA0_ms(unsigned int counter){
    TIMER_A0_config(counter);
}
void TimerA0_2_delay(unsigned int counter){
    TA0CCR0 = counter;
    TA0CTL |= TASSEL_2 + MC_1 + ID_3;//+ TACLR; //SMCLK, up mode
    TA0CCTL0 = CCIE;
    __bis_SR_register(LPM0_bits + GIE);       // Enter LPM0 w/ interrupt

}
//-----------------------------------------------
/* - - - - - - - LCD interface - - - - - - - - -
//-----------------------------------------------
 *  This code will interface to a standard LCD controller
 *  It uses it in 4 or 8 bit mode.
 */
//#include "msp430g2553.h"


//******************************************************************
// send a command to the LCD
//******************************************************************
void lcd_cmd(unsigned char c){

    LCD_WAIT; // may check LCD busy flag, or just delay a little, depending on lcd.h

    if (LCD_MODE == FOURBIT_MODE)
    {
        LCD_DATA_WRITE &= ~OUTPUT_DATA;// clear bits before new write
        LCD_DATA_WRITE |= ((c >> 4) & 0x0F) << LCD_DATA_OFFSET;
        lcd_strobe();
        LCD_DATA_WRITE &= ~OUTPUT_DATA;
        LCD_DATA_WRITE |= (c & (0x0F)) << LCD_DATA_OFFSET;
        lcd_strobe();
    }
    else
    {
        LCD_DATA_WRITE = c;
        lcd_strobe();
    }
}
//******************************************************************
// send data to the LCD
//******************************************************************
void lcd_data(unsigned char c){

    LCD_WAIT; // may check LCD busy flag, or just delay a little, depending on lcd.h

    LCD_DATA_WRITE &= ~OUTPUT_DATA;
    LCD_RS(1);
    if (LCD_MODE == FOURBIT_MODE)
    {
            LCD_DATA_WRITE &= ~OUTPUT_DATA;
                LCD_DATA_WRITE |= ((c >> 4) & 0x0F) << LCD_DATA_OFFSET;
        lcd_strobe();
                LCD_DATA_WRITE &= (0xF0 << LCD_DATA_OFFSET) | (0xF0 >> 8 - LCD_DATA_OFFSET);
                LCD_DATA_WRITE &= ~OUTPUT_DATA;
        LCD_DATA_WRITE |= (c & 0x0F) << LCD_DATA_OFFSET;
        lcd_strobe();
    }
    else
    {
        LCD_DATA_WRITE = c;
        lcd_strobe();
    }
    DelayMs(100);//--------------------dif
    LCD_RS(0);
}
//******************************************************************
// write a string of chars to the LCD
//******************************************************************
void lcd_puts(const char * s,int size){
  int lineCount=0;
  int updown=0;
  while(size){
        size--;
        lineCount++;
        if (lineCount>16){
            lineCount=0;
            if(updown == 0){
                updown=1;
                lcd_cmd(0xC0);
            }else if(updown == 1){
                updown=0;
                lcd_cmd(0x02);
            }

        }
        /*if (*s=="NUL"){
            *s=" ";
        }*/
        lcd_data(*s++);
  }
}
//******************************************************************
// initialize the LCD
//******************************************************************
void lcd_init(){

    char init_value;

    if (LCD_MODE == FOURBIT_MODE) init_value = 0x3 << LCD_DATA_OFFSET;
        else init_value = 0x3F;

    LCD_RS_DIR(OUTPUT_PIN);
    LCD_EN_DIR(OUTPUT_PIN);
    LCD_RW_DIR(OUTPUT_PIN);
    LCD_DATA_DIR |= OUTPUT_DATA;
    LCD_RS(0);
    LCD_EN(0);
    LCD_RW(0);

    DelayMs(15);
        LCD_DATA_WRITE &= ~OUTPUT_DATA;
    LCD_DATA_WRITE |= init_value;
    lcd_strobe();
    DelayMs(5);
        LCD_DATA_WRITE &= ~OUTPUT_DATA;
    LCD_DATA_WRITE |= init_value;
    lcd_strobe();
    DelayUs(200);
        LCD_DATA_WRITE &= ~OUTPUT_DATA;
    LCD_DATA_WRITE |= init_value;
    lcd_strobe();
    DelayUs(200);
    LCD_DATA_WRITE &= ~OUTPUT_DATA;
    LCD_DATA_WRITE |= init_value;
    lcd_strobe();

    if (LCD_MODE == FOURBIT_MODE){
        LCD_WAIT; // may check LCD busy flag, or just delay a little, depending on lcd.h
                LCD_DATA_WRITE &= ~OUTPUT_DATA;
        LCD_DATA_WRITE |= 0x2 << LCD_DATA_OFFSET; // Set 4-bit mode
        lcd_strobe();
        lcd_cmd(0x28); // Function Set
    }
        else lcd_cmd(0x3C); // 8bit,two lines,5x10 dots

    lcd_cmd(0xF); //Display On, Cursor On, Cursor Blink
    lcd_cmd(0x1); //Display Clear
    lcd_cmd(0x6); //Entry Mode
    lcd_cmd(0x80); //Initialize DDRAM address to zero
}
//******************************************************************
// lcd strobe functions
//******************************************************************
void lcd_strobe(){
  LCD_EN(1);
  __delay_cycles(1);
  __delay_cycles(1);
  LCD_EN(0);
}
//******************************************************************
// Delay usec functions
//******************************************************************
void DelayUs(unsigned int cnt){

    unsigned char i;
        for(i=cnt ; i>0 ; i--) __delay_cycles(1); // tha command asm("NOP") takes raphly 1usec

}
//******************************************************************
// Delay msec functions
//******************************************************************
void DelayMs(unsigned int cnt){

    unsigned char i;
        for(i=cnt ; i>0 ; i--) DelayUs(1000); // tha command asm("NOP") takes raphly 1usec

}

//********************************************************************
//            Port1 Interrupt Service Rotine
//*********************************************************************
// joystick
#pragma vector=PORT1_VECTOR
  __interrupt void PBs_handler(void){

      DelayMs(75000);
      __bic_SR_register(GIE);

//        TA1CTL &= ~MC_2;
//        TA1CTL &= ~MC_1;
//        TA0CTL &= ~MC_3;
//---------------------------------------------------------------------
//            selector of transition between states
//---------------------------------------------------------------------
    if (JoyStickIntPend & 0x20) {
        JoyStickIntPend &= ~0x20;  // Clear PB0 interrupt flag
        if((state == calibration) || (state==JoystickRotation)){
            if (stepState == Idlestep){
                stepState=Rotate;
                rotateFlag=1;
            }
            else if (stepState == Rotate){
                stepState=StopRotate;
                rotateFlag=0;
            }
            else if (stepState == StopRotate){
                stepState = Idlestep;
                rotateFlag=0;
            }
            __bis_SR_register(GIE);
        }
        else if(state == Painter){
            IE2 &= ~UCA0TXIE;
              __bic_SR_register(GIE);
              while (!(UCA0TXIFG)){
                asm("nop");
            }

              UCA0TXBUF=(0x99); //change painter mode
              IE2 |= UCA0TXIE; // enable USCI_A0 TX interrupt to stop further transmissions
              __bis_SR_register(LPM0_bits+GIE);

        }
    }
//---------------------------------------------------------------------
//            Exit from a given LPM
//---------------------------------------------------------------------
        switch(lpm_mode){
        case mode0:
         LPM0_EXIT; // must be called from ISR only
         break;

        case mode1:
         LPM1_EXIT; // must be called from ISR only
         break;

        case mode2:
         LPM2_EXIT; // must be called from ISR only
         break;

                case mode3:
         LPM3_EXIT; // must be called from ISR only
         break;

                case mode4:
         LPM4_EXIT; // must be called from ISR only
         break;
    }

}
  //*********************************************************************
  //                         ADC10 ISR
  //*********************************************************************
  #pragma vector = ADC10_VECTOR
  __interrupt void ADC10_ISR (void)
  {
     LPM0_EXIT;  // Exit Low Power Mode 0
  }

  //***********************************TX ISR******************************************
  // Interrupt Service Routine (ISR) for USCI0 TX (Transmit) vector.
  // This ISR is triggered when the UART transmit buffer is ready to accept new data.
  #if defined(__TI_COMPILER_VERSION__) || defined(__IAR_SYSTEMS_ICC__)
  #pragma vector=USCIAB0TX_VECTOR
  __interrupt void USCI0TX_ISR(void)
  #elif defined(__GNUC__)
  void __attribute__ ((interrupt(USCIAB0TX_VECTOR))) USCI0TX_ISR (void)
  #else
  #error Compiler not supported!
  #endif
  {
      if (state==calibration){
          //UCA0TXBUF=0;
          stepState=Idlestep;
          //IE2 &= ~UCA0TXIE; // Disable USCI_A0 TX interrupt to stop further transmissions
      }
      if (state==Script){

          while (1){
              if (UCA0TXBUF==0x22){
                 // TIMERA0_delay_ms(0xffff);
                  break;
              }
              UCA0TXBUF=angles[Tx_index];
              Tx_index++;
              TIMERA0_delay_ms(0xffff);
              //TIMERA0_delay_ms(0xffff);
              if (angles[Tx_index-1]=='\n'){
                  Tx_index=0;
                  memset(angles,0,5);
                  break;
              }
          }
      }
      IE2 &= ~UCA0TXIE;
      __bic_SR_register_on_exit(((0x0010)));  // Exit Low Power Mode 0

  }
  //---------------------------------------------------------------------
  //            USCI A0/B0 Receive ISR
  //---------------------------------------------------------------------
  #if defined(__TI_COMPILER_VERSION__) || defined(__IAR_SYSTEMS_ICC__)
  #pragma vector=USCIAB0RX_VECTOR
  __interrupt void USCI0RX_ISR(void)
  #elif defined(__GNUC__)
  void __attribute__ ((interrupt(USCIAB0RX_VECTOR))) USCI0RX_ISR (void)
  #else
  #error Compiler not supported!
  #endif
  {
    input[input_slot] = UCA0RXBUF;
    input_slot++;
    int i;
            switch(input[input_slot-1]){
                case 'M':
                    for (i=0;i<input_slot-3;i++){
                        memoryFiles.file_names[i]=input[i];
                        input[i]=0;
                    }
                    input[input_slot-2]=0;
                    input[input_slot-1]=0;
                    input_slot=0;
                    break;
                case 'L' :
                    state = calibration;
                    stepState = Idlestep;
                    input_slot=0;
                    break;
                case 'I' :
                    state = Idle;
                    stepState = Idlestep;
                    input_slot=0;
                    break;
                case 'J' :
                    state = JoystickRotation;
                    stepState = Idlestep;
                    input_slot=0;
                    break;
                case 'P' :
                    state = Painter;
                    stepState = Idlestep;
                    input_slot=0;
                    break;
                case 'S':
                    state = Script;
                    stepState = Idlestep;
                    input_slot=0;
                    break;
                case 'K': //ack painter
                    ack=1;
                    input_slot=0;
                    LPM0_EXIT;
                    break;
                //=====script get file
                case 'O':
                    strcpy(Rec_data,input);//coppying 'E' as well
                    memoryFiles.file_sizes[0]=input_slot;
                    input_slot=0;
                    file_uploaded_ind=1;
                    memoryFiles.file_pointers[0]=(char*) 0x1000;
                    memoryFiles.total_files=1;
                    break;
                case 'W':
                    strcpy(Rec_data,input);//coppying 'F' as well
                    memoryFiles.file_sizes[1]=input_slot;
                    input_slot=0;
                    file_uploaded_ind=1;
                    memoryFiles.file_pointers[1]=(char*) 0x1040;
                    memoryFiles.total_files=2;
                    break;
                case 'G':
                    strcpy(Rec_data,input);//coppying 'G' as well
                    memoryFiles.file_sizes[2]=input_slot;
                    input_slot=0;
                    file_uploaded_ind=1;
                    memoryFiles.file_pointers[2]=(char*) 0x1080;
                    memoryFiles.total_files=3;
                    break;
               //====script execute file
                case 'Z':
                    execute_pointer= memoryFiles.file_pointers[0];
                    input_slot=0;
                    file_execute_ind=1;
                    break;
                case 'N':
                    execute_pointer= memoryFiles.file_pointers[1];
                    input_slot=0;
                    file_execute_ind=1;
                    break;
                case 'H':
                    execute_pointer= memoryFiles.file_pointers[2];
                    input_slot=0;
                    file_execute_ind=1;
                    break;




                  //    IE2 |= UCA0TXIE;                        // Enable USCI_A0 TX interrupt
            }
            /*if (input[input_slot-1]=='\x0a'){//a file name was sent
                for (i=0;i<input_slot;i++){
                    memoryFiles.file_names[i]=input[i];
                    input[i]=0;
                }
                input_slot=0;
            }*/
            //input_slot=0;
  //---------------------------------------------------------------------
  //            Exit from a given LPM
  //---------------------------------------------------------------------
        switch(lpm_mode){
            case mode0:
             LPM0_EXIT; // must be called from ISR only
             break;

            case mode1:
             LPM1_EXIT; // must be called from ISR only
             break;

            case mode2:
             LPM2_EXIT; // must be called from ISR only
             break;

                    case mode3:
             LPM3_EXIT; // must be called from ISR only
             break;

                    case mode4:
             LPM4_EXIT; // must be called from ISR only
             break;
        }
  }
//*********************************************************************
//                        TIMER A0 ISR
//*********************************************************************
#pragma vector = TIMER0_A0_VECTOR // For delay
__interrupt void TimerA_ISR (void)
{
  if ((state==Painter)&&(ack==0)){
      ack=1;
  }
  StopAllTimers();
  LPM0_EXIT;
}
