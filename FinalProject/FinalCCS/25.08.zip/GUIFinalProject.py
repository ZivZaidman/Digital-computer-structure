import PySimpleGUI as sg
import serial as ser
import sys, glob
import time
import serial.tools.list_ports
from tkinter import *
from tkinter.colorchooser import askcolor
import mouse
import os
from os import path
import threading
import binascii
import pyautogui
#---------------GUI definition--------------#
#----Main window-----#
sg.theme('DarkGrey9')
layout=[[sg.Button("calibaration", size=(30,4),button_color=("white", "green"), font=("Helvetica", 14))
            , sg.Button("Joystick Controled Rotation", size=(30,4),button_color=("white", "green"), font=("Helvetica", 14))],
        [sg.Button("Joystick Painter", size=(30,4),button_color=("white", "green"), font=("Helvetica", 14))
            ,sg.Exit(size=(30,4),button_color=("white", "green"), font=("Helvetica", 14))]]

window = sg.Window("Final project Menu", layout)
#-----UARTconfig-----#
s = ser.Serial('COM5', baudrate=9600, bytesize=ser.EIGHTBITS,
               parity=ser.PARITY_NONE, stopbits=ser.STOPBITS_ONE,
               timeout=1)  # timeout of 1 sec so that the read and write operations are blocking,
# when the timeout expires the program will continue
# clear buffers
s.reset_input_buffer()
s.reset_output_buffer()
#----Calibration window-----#
RotationCounter=0
degreesCounter=RotationCounter*0.088
def open_calibration_window():
    s.write(bytes('C' + '\n', 'ascii'))
    time.sleep(0.25)  # Delay for accurate read/write operations
    s.reset_output_buffer()
    while True:
        if s.in_waiting > 0:
            received_data = s.read_until(expected=b'\n')
            received_int = int.from_bytes(received_data,byteorder='little')
            print(f"Received (as int): {received_int}")
            break
            # Process the received data here
    calibration_layout = [[sg.Text("Rotations Counter:"), sg.Text(received_int)],
                          [[sg.Text("degrees:"), sg.Text(degreesCounter)]],
                          [sg.Exit(size=(15, 2), button_color=("white", "green"), font=("Helvetica", 14))]]

    calibration_window = sg.Window("Calibaration", calibration_layout)

    while True:
        calibration_event, _ = calibration_window.read()
        if (calibration_event in (sg.WIN_CLOSED, "Exit")):
            s.write(bytes('I' + '\n', 'ascii'))
            time.sleep(0.25)  # Delay for accurate read/write operations
            s.reset_output_buffer()
            break
    window.close()
def opem_JoystickRotation_window():
    s.write(bytes('J' + '\n', 'ascii'))
    time.sleep(0.25)  # Delay for accurate read/write operations
    s.reset_output_buffer()
    joystickRotation_layout = [[sg.Text("Use your Joystick to rotate the stepmotor")],
                          [sg.Exit(size=(15, 2), button_color=("white", "green"), font=("Helvetica", 14))]]
    joystickRotation_window=sg.Window("joystickRotation",joystickRotation_layout)
    while True:
        joystickRotation_event,_=joystickRotation_window.read()
        if (joystickRotation_event in (sg.WIN_CLOSED, "Exit")):
            s.write(bytes('I' + '\n', 'ascii'))
            time.sleep(0.25)  # Delay for accurate read/write operations
            s.reset_output_buffer()
            break
    window.close()
# -----main event loop-----#
while True:
    event, _ = window.read()
    if (event in (sg.WIN_CLOSED, "Exit")):
        s.write(bytes('I' + '\n', 'ascii'))
        time.sleep(0.25)  # Delay for accurate read/write operations
        s.reset_output_buffer()
        break
    if (event == "calibaration"):
        sg.popup(open_calibration_window())
    if (event=="Joystick Controled Rotation"):
        sg.popup(opem_JoystickRotation_window())
    if (event=="Joystick Painter"):
        sg.popup("joystickpainter")
window.close()

