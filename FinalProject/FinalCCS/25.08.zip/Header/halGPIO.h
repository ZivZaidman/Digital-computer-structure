#ifndef HALGPIO_H_
#define HALGPIO_H_
#include "../header/bsp.h"
#include "../header/app.h"

extern enum FSMstate state;   // global variable
extern enum Stepperstate stateStepp;
extern enum SYSmode lpm_mode; // global variable
extern void sysConfig(void);
extern int rotateFlag;
extern int rotationCounter;
extern int input_slot;
extern char input[80];

#endif
// #define CHECKBUSY    1  // using this define, only if we want to read from LCD

#ifdef CHECKBUSY
    #define LCD_WAIT lcd_check_busy()
#else
    #define LCD_WAIT DelayMs(5)
#endif

// LCD
/*----------------------------------------------------------
  CONFIG: change values according to your port pin selection
------------------------------------------------------------*/
#define LCD_EN(a)   (!a ? (P1OUT&=~0X01) : (P1OUT|=0X01)) // P1.0 is lcd enable pin
#define LCD_EN_DIR(a)   (!a ? (P1DIR&=~0X01) : (P1DIR|=0X01)) // P1.0 pin direction

#define LCD_RS(a)   (!a ? (P1OUT&=~0X40) : (P1OUT|=0X40)) // P1.6 is lcd RS pin
#define LCD_RS_DIR(a)   (!a ? (P1DIR&=~0X40) : (P1DIR|=0X40)) // P1.6 pin direction

#define LCD_RW(a)   (!a ? (P1OUT&=~0X80) : (P1OUT|=0X80)) // P1.7 is lcd RW pin
#define LCD_RW_DIR(a)   (!a ? (P1DIR&=~0X80) : (P1DIR|=0X80)) // P1.7 pin direction

#define LCD_DATA_OFFSET 0x04 //data pin selection offset for 4 bit mode, variable range is 0-4, default 0 - Px.0-3, no offset


/*---------------------------------------------------------
  END CONFIG
-----------------------------------------------------------*/

extern void lcd_puts(const char * s,int size);
extern void lcd_strobe();
extern void lcd_data(unsigned char);
extern void lcd_cmd(unsigned char);
extern void lcd_init();
extern int division();

#define FOURBIT_MODE    0x0
#define EIGHTBIT_MODE   0x1
#define LCD_MODE        FOURBIT_MODE
#define OUTPUT_PIN      1
#define INPUT_PIN       0
#define OUTPUT_DATA     (LCD_MODE ? 0xFF : (0x0F << LCD_DATA_OFFSET))
#define INPUT_DATA      0x00
#define MULTIPLY_FP_RESOLUTION_BITS 15
#define lcd_clear()         lcd_cmd(0x01)
