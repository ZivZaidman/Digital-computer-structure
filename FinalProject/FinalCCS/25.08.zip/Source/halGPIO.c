#include  "../header/halGPIO.h"     // private library - HAL layer

enum FSMstate state;
enum Motorstate stepState;
enum SYSmode lpm_mode;

//Global variables:
int rotateFlag = 1;
int rotationCounter =0;

//--------------------------------------------------------------------
//             System Configuration
//--------------------------------------------------------------------
void sysConfig(void){
    GPIOconfig();
    ADCconfig();
    StopAllTimers();
    UARTConfig();
}
//-------------------ATAN2- Fixed point - returns degrees---------------------------
/*int16_t calculate_angle(int16_t y_val, int16_t x_val)
{
    // Coefficients for fixed-point calculations
    int32_t base_angle = 45;         // Coefficient for fixed-point atan2 approximation
    int32_t first_adjustment = -56;  // Coefficient for fixed-point atan2 approximation
    int32_t cubic_adjustment = 11;   // Coefficient for fixed-point atan2 approximation
    int16_t offset_angle = 135;      // Additional coefficient used for final angle calculation

    int16_t final_angle = 0;         // Variable to hold the computed angle

    int32_t ratio;                   // Temporary variable to hold intermediate result
    int32_t ratio_cubed;             // Variable to hold ratio^3

    int16_t y_abs_val = y_val;       // Absolute value of y_val
    if (y_abs_val < 0)
        y_abs_val = -y_abs_val;      // Make y_abs_val positive if it's negative

    // Determine angle based on the quadrant of (x_val, y_val)
    if (y_val == 0)
    {
        // If y_val is zero, angle is either 0 or 180 degrees based on x_val
        if (x_val >= 0)
        {
            final_angle = 0;   // Positive x-axis
        }
        else
        {
            final_angle = 180; // Negative x-axis
        }
    }
    else if (x_val >= 0)
    {
        // Case where x_val is non-negative (Quadrants I or IV)
        ratio = (((int32_t)(x_val - y_abs_val)) << FIXED_POINT_RESOLUTION_BITS) /
            ((int32_t)(x_val + y_abs_val)); // Compute ratio for angle calculation

        ratio_cubed = ratio * ratio;                         // Calculate ratio^2
        ratio_cubed = ratio_cubed >> FIXED_POINT_RESOLUTION_BITS; // Adjust for fixed-point resolution
        ratio_cubed *= ratio;                               // Calculate ratio^3
        ratio_cubed = ratio_cubed >> FIXED_POINT_RESOLUTION_BITS; // Adjust for fixed-point resolution
        ratio_cubed *= cubic_adjustment;                    // Multiply by cubic adjustment coefficient
        final_angle = (int16_t) (base_angle + ((first_adjustment * ratio + ratio_cubed) >> FIXED_POINT_RESOLUTION_BITS)); // Calculate final angle
    }
    else
    {
        // Case where x_val is negative (Quadrants II or III)
        ratio = (((int32_t)(x_val + y_abs_val)) << FIXED_POINT_RESOLUTION_BITS) /
            ((int32_t)(y_abs_val - x_val)); // Compute ratio for angle calculation
        ratio_cubed = ratio * ratio;                         // Calculate ratio^2
        ratio_cubed = ratio_cubed >> FIXED_POINT_RESOLUTION_BITS; // Adjust for fixed-point resolution
        ratio_cubed *= ratio;                               // Calculate ratio^3
        ratio_cubed = ratio_cubed >> FIXED_POINT_RESOLUTION_BITS; // Adjust for fixed-point resolution
        ratio_cubed *= cubic_adjustment;                    // Multiply by cubic adjustment coefficient
        final_angle = offset_angle + ((int16_t) (((first_adjustment * ratio + ratio_cubed) >> FIXED_POINT_RESOLUTION_BITS))); // Calculate final angle
    }

    // Adjust angle based on the sign of y_val
    if (y_val < 0)
        return (360 - final_angle);  // Invert angle if y_val is negative (Quadrants III or IV)
    else
        return final_angle;         // Return calculated angle for other cases
}
*/
//-------------------ATAN2- Fixed point - returns degrees---------------------------
int16_t tangens(int16_t y_fp, int16_t x_fp)
{
    // Coefficients for fixed-point calculations
    int32_t coeff_1 = 45;        // Coefficient for fixed-point atan2 approximation
    int32_t coeff_1b = -56;      // Coefficient for fixed-point atan2 approximation
    int32_t coeff_1c = 11;       // Coefficient for fixed-point atan2 approximation
    int16_t coeff_2 = 135;       // Additional coefficient used for final angle calculation

    int16_t angle = 0;           // Variable to hold the computed angle

    int32_t r;                   // Temporary variable to hold intermediate result
    int32_t r3;                  // Variable to hold r^3

    int16_t y_abs_fp = y_fp;     // Absolute value of y_fp
    if (y_abs_fp < 0)
        y_abs_fp = -y_abs_fp;    // Make y_abs_fp positive if it's negative

    // Determine angle based on the quadrant of (x_fp, y_fp)
    if (y_fp == 0)
    {
        // If y_fp is zero, angle is either 0 or 180 degrees based on x_fp
        if (x_fp >= 0)
        {
            angle = 0;   // Positive x-axis
        }
        else
        {
            angle = 180; // Negative x-axis
        }
    }
    else if (x_fp >= 0)
    {
        // Case where x_fp is non-negative (Quadrants I or IV)
        r = (((int32_t)(x_fp - y_abs_fp)) << MULTIPLY_FP_RESOLUTION_BITS) /
            ((int32_t)(x_fp + y_abs_fp)); // Compute r for angle calculation

        r3 = r * r;                       // Calculate r^2
        r3 = r3 >> MULTIPLY_FP_RESOLUTION_BITS; // Adjust for fixed-point resolution
        r3 *= r;                         // Calculate r^3
        r3 = r3 >> MULTIPLY_FP_RESOLUTION_BITS; // Adjust for fixed-point resolution
        r3 *= coeff_1c;                  // Multiply by coefficient
        angle = (int16_t) (coeff_1 + ((coeff_1b * r + r3) >> MULTIPLY_FP_RESOLUTION_BITS)); // Calculate final angle
    }
    else
    {
        // Case where x_fp is negative (Quadrants II or III)
        r = (((int32_t)(x_fp + y_abs_fp)) << MULTIPLY_FP_RESOLUTION_BITS) /
            ((int32_t)(y_abs_fp - x_fp)); // Compute r for angle calculation
        r3 = r * r;                       // Calculate r^2
        r3 = r3 >> MULTIPLY_FP_RESOLUTION_BITS; // Adjust for fixed-point resolution
        r3 *= r;                         // Calculate r^3
        r3 = r3 >> MULTIPLY_FP_RESOLUTION_BITS; // Adjust for fixed-point resolution
        r3 *= coeff_1c;                  // Multiply by coefficient
        angle = coeff_2 + ((int16_t) (((coeff_1b * r + r3) >> MULTIPLY_FP_RESOLUTION_BITS))); // Calculate final angle
    }

    // Adjust angle based on the sign of y_fp
    if (y_fp < 0)
        return (360 - angle);  // Invert angle if y_fp is negative (Quadrants III or IV)
    else
        return angle;         // Return calculated angle for other cases
}
//------------Q-point division--------------------
int division(int dividend, int divisor) {
    /* division function to create a division between 2 integers with the result multiplied by 1000 in order to get the result as integer */
    int quotient = 0;           // Initialize quotient to store the final result
    int multiplier = 1000;      // Define a multiplier to scale up the dividend to avoid fractions

    dividend *= multiplier;     // Scale up the dividend by the multiplier to handle integer division

    // Loop until the dividend is smaller than the divisor
    while (dividend >= divisor) {
        int temp_divisor = divisor;   // Create a temporary divisor for shifting operations
        int temp_quotient = 1;        // Temporary quotient initialized to 1 for the shifting process

        // Shift temp_divisor left until it's larger than the dividend
        while ((temp_divisor << 1) <= dividend) {
            temp_divisor <<= 1;      // Shift temp_divisor left (equivalent to multiplying by 2)
            temp_quotient <<= 1;     // Shift temp_quotient left (equivalent to multiplying by 2)
        }

        dividend -= temp_divisor;    // Subtract the largest shifted divisor from the dividend
        quotient += temp_quotient;   // Add the corresponding quotient to the final result
    }

    return quotient;                 // Return the final quotient, which is dividend/divisor�*�1000
}

//-----------------------------------------------
//              StepMotor functions
//-----------------------------------------------
void clockwiseRotation(){
    StepmotorPortOUT = 0x01;
    TIMERA0_delay_ms(1000);
    StepmotorPortOUT = 0x08;
    TIMERA0_delay_ms(1000);
    StepmotorPortOUT = 0x04;
    TIMERA0_delay_ms(1000);
    StepmotorPortOUT = 0x02;
}
//-----------------------------------------------
//                   Timers
//-----------------------------------------------
//            Start Timer0 With counter
void TIMERA0_delay_ms(unsigned int counter){
    TIMER_A0_config(counter);
    __bis_SR_register(LPM0_bits + GIE);       // Enter LPM0 w/ interrupt
}
//-----------------------------------------------
/* - - - - - - - LCD interface - - - - - - - - -
//-----------------------------------------------
 *  This code will interface to a standard LCD controller
 *  It uses it in 4 or 8 bit mode.
 */
//#include "msp430g2553.h"


//******************************************************************
// send a command to the LCD
//******************************************************************
void lcd_cmd(unsigned char c){

    LCD_WAIT; // may check LCD busy flag, or just delay a little, depending on lcd.h

    if (LCD_MODE == FOURBIT_MODE)
    {
        LCD_DATA_WRITE &= ~OUTPUT_DATA;// clear bits before new write
        LCD_DATA_WRITE |= ((c >> 4) & 0x0F) << LCD_DATA_OFFSET;
        lcd_strobe();
        LCD_DATA_WRITE &= ~OUTPUT_DATA;
        LCD_DATA_WRITE |= (c & (0x0F)) << LCD_DATA_OFFSET;
        lcd_strobe();
    }
    else
    {
        LCD_DATA_WRITE = c;
        lcd_strobe();
    }
}
//******************************************************************
// send data to the LCD
//******************************************************************
void lcd_data(unsigned char c){

    LCD_WAIT; // may check LCD busy flag, or just delay a little, depending on lcd.h

    LCD_DATA_WRITE &= ~OUTPUT_DATA;
    LCD_RS(1);
    if (LCD_MODE == FOURBIT_MODE)
    {
            LCD_DATA_WRITE &= ~OUTPUT_DATA;
                LCD_DATA_WRITE |= ((c >> 4) & 0x0F) << LCD_DATA_OFFSET;
        lcd_strobe();
                LCD_DATA_WRITE &= (0xF0 << LCD_DATA_OFFSET) | (0xF0 >> 8 - LCD_DATA_OFFSET);
                LCD_DATA_WRITE &= ~OUTPUT_DATA;
        LCD_DATA_WRITE |= (c & 0x0F) << LCD_DATA_OFFSET;
        lcd_strobe();
    }
    else
    {
        LCD_DATA_WRITE = c;
        lcd_strobe();
    }
    DelayMs(100);//--------------------dif
    LCD_RS(0);
}
//******************************************************************
// write a string of chars to the LCD
//******************************************************************
void lcd_puts(const char * s,int size){
  int lineCount=0;
  int updown=0;
  while(size){
        size--;
        lineCount++;
        if (lineCount>16){
            lineCount=0;
            if(updown == 0){
                updown=1;
                lcd_cmd(0xC0);
            }else if(updown == 1){
                updown=0;
                lcd_cmd(0x02);
            }

        }
        /*if (*s=="NUL"){
            *s=" ";
        }*/
        lcd_data(*s++);
  }
}
//******************************************************************
// initialize the LCD
//******************************************************************
void lcd_init(){

    char init_value;

    if (LCD_MODE == FOURBIT_MODE) init_value = 0x3 << LCD_DATA_OFFSET;
        else init_value = 0x3F;

    LCD_RS_DIR(OUTPUT_PIN);
    LCD_EN_DIR(OUTPUT_PIN);
    LCD_RW_DIR(OUTPUT_PIN);
//    LCD_DATA_DIR |= OUTPUT_DATA;
    LCD_RS(0);
    LCD_EN(0);
    LCD_RW(0);

    DelayMs(15);
        LCD_DATA_WRITE &= ~OUTPUT_DATA;
    LCD_DATA_WRITE |= init_value;
    lcd_strobe();
    DelayMs(5);
        LCD_DATA_WRITE &= ~OUTPUT_DATA;
    LCD_DATA_WRITE |= init_value;
    lcd_strobe();
    DelayUs(200);
        LCD_DATA_WRITE &= ~OUTPUT_DATA;
    LCD_DATA_WRITE |= init_value;
    lcd_strobe();

    if (LCD_MODE == FOURBIT_MODE){
        LCD_WAIT; // may check LCD busy flag, or just delay a little, depending on lcd.h
                LCD_DATA_WRITE &= ~OUTPUT_DATA;
        LCD_DATA_WRITE |= 0x2 << LCD_DATA_OFFSET; // Set 4-bit mode
        lcd_strobe();
        lcd_cmd(0x28); // Function Set
    }
        else lcd_cmd(0x3C); // 8bit,two lines,5x10 dots

    lcd_cmd(0xF); //Display On, Cursor On, Cursor Blink
    lcd_cmd(0x1); //Display Clear
    lcd_cmd(0x6); //Entry Mode
    lcd_cmd(0x80); //Initialize DDRAM address to zero
}
//******************************************************************
// lcd strobe functions
//******************************************************************
void lcd_strobe(){
  LCD_EN(1);
  __delay_cycles(1);
  __delay_cycles(1);
  LCD_EN(0);
}
//******************************************************************
// Delay usec functions
//******************************************************************
void DelayUs(unsigned int cnt){

    unsigned char i;
        for(i=cnt ; i>0 ; i--) __delay_cycles(1); // tha command asm("NOP") takes raphly 1usec

}
//******************************************************************
// Delay msec functions
//******************************************************************
void DelayMs(unsigned int cnt){

    unsigned char i;
        for(i=cnt ; i>0 ; i--) DelayUs(1000); // tha command asm("NOP") takes raphly 1usec

}
//********************************************************************
//            Port1 Interrupt Service Rotine
//*********************************************************************
#pragma vector=PORT1_VECTOR
  __interrupt void PBs_handler(void){

      DelayMs(75000);
//        TA1CTL &= ~MC_2;
//        TA1CTL &= ~MC_1;
//        TA0CTL &= ~MC_3;
//---------------------------------------------------------------------
//            selector of transition between states
//---------------------------------------------------------------------
    if (JoyStickIntPend & 0x20) {
//        state = state1;
        JoyStickIntPend &= ~0x20;  // Clear PB0 interrupt flag
        if (stepState == Idlestep){
            stepState=Rotate;
            rotateFlag=1;
        }
        else if (stepState == Rotate){
            stepState=StopRotate;
            rotateFlag=0;
        }
        else if (stepState == StopRotate){
            stepState = Idlestep;
            rotateFlag=0;
        }
    }
//---------------------------------------------------------------------
//            Exit from a given LPM
//---------------------------------------------------------------------
        switch(lpm_mode){
        case mode0:
         LPM0_EXIT; // must be called from ISR only
         break;

        case mode1:
         LPM1_EXIT; // must be called from ISR only
         break;

        case mode2:
         LPM2_EXIT; // must be called from ISR only
         break;

                case mode3:
         LPM3_EXIT; // must be called from ISR only
         break;

                case mode4:
         LPM4_EXIT; // must be called from ISR only
         break;
    }

}
  //*********************************************************************
  //                         ADC10 ISR
  //*********************************************************************
  #pragma vector = ADC10_VECTOR
  __interrupt void ADC10_ISR (void)
  {
     LPM0_EXIT;  // Exit Low Power Mode 0
  }

  //***********************************TX ISR******************************************
  // Interrupt Service Routine (ISR) for USCI0 TX (Transmit) vector.
  // This ISR is triggered when the UART transmit buffer is ready to accept new data.
  #if defined(__TI_COMPILER_VERSION__) || defined(__IAR_SYSTEMS_ICC__)
  #pragma vector=USCIAB0TX_VECTOR
  __interrupt void USCI0TX_ISR(void)
  #elif defined(__GNUC__)
  void __attribute__ ((interrupt(USCIAB0TX_VECTOR))) USCI0TX_ISR (void)
  #else
  #error Compiler not supported!
  #endif
  {
      //UCA0TXBUF=0;
      stepState=Idlestep;
      IE2 &= ~UCA0TXIE; // Disable USCI_A0 TX interrupt to stop further transmissions
  }
  //---------------------------------------------------------------------
  //            USCI A0/B0 Receive ISR
  //---------------------------------------------------------------------
  #if defined(__TI_COMPILER_VERSION__) || defined(__IAR_SYSTEMS_ICC__)
  #pragma vector=USCIAB0RX_VECTOR
  __interrupt void USCI0RX_ISR(void)
  #elif defined(__GNUC__)
  void __attribute__ ((interrupt(USCIAB0RX_VECTOR))) USCI0RX_ISR (void)
  #else
  #error Compiler not supported!
  #endif
  {
    input[input_slot] = UCA0RXBUF;
    input_slot++;
            switch(input[0]){
                case 'C' :
                    state = calibration;
                    stepState = Idlestep;
                    input_slot=0;
                    break;
                case 'I' :
                    state = Idle;
                    stepState = Idlestep;
                    input_slot=0;
                    break;
                case 'J' :
                    state = JoystickRotation;
                    stepState = Idlestep;
                    input_slot=0;
                    break;
                case '4' :
                    state = state4;
                    break;
                case '5' :
                    state = state5;
                    break;
                case '6' :
                    state = state6;
                    break;

                  //    IE2 |= UCA0TXIE;                        // Enable USCI_A0 TX interrupt
            }
            input_slot=0;
  //---------------------------------------------------------------------
  //            Exit from a given LPM
  //---------------------------------------------------------------------
        switch(lpm_mode){
            case mode0:
             LPM0_EXIT; // must be called from ISR only
             break;

            case mode1:
             LPM1_EXIT; // must be called from ISR only
             break;

            case mode2:
             LPM2_EXIT; // must be called from ISR only
             break;

                    case mode3:
             LPM3_EXIT; // must be called from ISR only
             break;

                    case mode4:
             LPM4_EXIT; // must be called from ISR only
             break;
        }
  }
//*********************************************************************
//                        TIMER A0 ISR
//*********************************************************************
#pragma vector = TIMER0_A0_VECTOR // For delay
__interrupt void TimerA_ISR (void)
{
  StopAllTimers();
  LPM0_EXIT;
}
