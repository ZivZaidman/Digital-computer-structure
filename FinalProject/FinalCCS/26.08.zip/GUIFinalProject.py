import PySimpleGUI as sg
import serial as ser
import sys, glob
import time
import serial.tools.list_ports
from tkinter import *
from tkinter.colorchooser import askcolor
import mouse
import os
from os import path
import threading
import binascii
import pyautogui
#---------------GUI definition--------------#
#----Main window-----#
sg.theme('DarkGrey9')
layout=[[sg.Button("calibaration", size=(30,4),button_color=("white", "green"), font=("Helvetica", 14))
            , sg.Button("Joystick Controled Rotation", size=(30,4),button_color=("white", "green"), font=("Helvetica", 14))],
        [sg.Button("Joystick Painter", size=(30,4),button_color=("white", "green"), font=("Helvetica", 14))
            ,sg.Button("Script",size=(30,4),button_color=("white", "green"), font=("Helvetica", 14))],
        [sg.Exit(size=(61,2),button_color=("white", "darkred"), font=("Helvetica", 14))]]

window = sg.Window("Final project Menu", layout)
#-----UARTconfig-----#
s = ser.Serial('COM5', baudrate=9600, bytesize=ser.EIGHTBITS,
               parity=ser.PARITY_NONE, stopbits=ser.STOPBITS_ONE,
               timeout=1)  # timeout of 1 sec so that the read and write operations are blocking,
# when the timeout expires the program will continue
# clear buffers
s.reset_input_buffer()
s.reset_output_buffer()
#----Calibration window-----#
RotationCounter=0
degreesCounter=RotationCounter*0.088
def open_calibration_window():
    s.write(bytes('C' + '\n', 'ascii'))
    time.sleep(0.25)  # Delay for accurate read/write operations
    s.reset_output_buffer()
    while True:
        if s.in_waiting > 0:
            received_data = s.read_until(expected=b'\n')
            received_int = int.from_bytes(received_data,byteorder='little')
            print(f"Received (as int): {received_int}")
            break
            # Process the received data here
    calibration_layout = [[sg.Text("Rotations Counter:"), sg.Text(received_int)],
                          [[sg.Text("degrees:"), sg.Text(degreesCounter)]],
                          [sg.Exit(size=(15, 2), button_color=("white", "green"), font=("Helvetica", 14))]]

    calibration_window = sg.Window("Calibaration", calibration_layout)

    while True:
        calibration_event, _ = calibration_window.read()
        if (calibration_event in (sg.WIN_CLOSED, "Exit")):
            s.write(bytes('I' + '\n', 'ascii'))
            time.sleep(0.25)  # Delay for accurate read/write operations
            s.reset_output_buffer()
            break
    calibration_window.close()
def opem_JoystickRotation_window():
    s.write(bytes('J' + '\n', 'ascii'))
    time.sleep(0.25)  # Delay for accurate read/write operations
    s.reset_output_buffer()
    joystickRotation_layout = [[sg.Text("Use your Joystick to rotate the stepmotor")],
                          [sg.Exit(size=(15, 2), button_color=("white", "green"), font=("Helvetica", 14))]]
    joystickRotation_window=sg.Window("joystickRotation",joystickRotation_layout)
    while True:
        joystickRotation_event,_=joystickRotation_window.read()
        if (joystickRotation_event in (sg.WIN_CLOSED, "Exit")):
            s.write(bytes('I' + '\n', 'ascii'))
            time.sleep(0.25)  # Delay for accurate read/write operations
            s.reset_output_buffer()
            break
    joystickRotation_window.close()
def open_canvas():
    s.write(bytes('P' + '\n', 'ascii'))
    time.sleep(0.25)  # Delay for accurate read/write operations
    s.reset_output_buffer()
    Canvas_layout=[[sg.Graph(
        canvas_size=(400, 400),
        graph_bottom_left=(0, 0),
        graph_top_right=(400, 400),
        background_color='white',
        key='-GRAPH-'
    )],
    [sg.Button('Clear', size=(10, 1),button_color=("white", "green"), font=("Helvetica", 14)), sg.Button('Exit', size=(10, 1),button_color=("white", "green"), font=("Helvetica", 14))]
    ]
    painter_window=sg.Window('joystick Painter',Canvas_layout, finalize=True)
    graph = painter_window['-GRAPH-']
    last_position = None
    drawing = False
    while True:
        painter_event,values=painter_window.read()
        if painter_event in (sg.WIN_CLOSED, "Exit"):
            s.write(bytes('I' + '\n', 'ascii'))
            time.sleep(0.25)  # Delay for accurate read/write operations
            s.reset_output_buffer()
            break
        if event == 'Clear':
            graph.Erase()  # Clear the canvas

        if event == '-GRAPH-':
            mouse = values['-GRAPH-']
            # Start drawing when the mouse is pressed
            if not drawing and mouse:
                last_position = mouse
                drawing = True

            # Draw while the mouse is being dragged
            if drawing and mouse:
                if last_position:
                    graph.DrawLine(last_position, mouse, width=2, color='black')
                last_position = mouse

        if event.endswith('+UP'):  # When mouse button is released
            drawing = False
            last_position = None
    painter_window.close()
def open_script_mode():
    script_layout=[[sg.Text("Choose a flie:"),sg.Input(key="IN"),sg.FileBrowse(button_color=("white", "green"))],
                   [sg.Button("Exit",button_color=("white", "darkred")),sg.Button("upload File",button_color=("white", "green"))]]
    script_window=sg.Window("Uploading a File to the MSP430", script_layout)
    while True:
        script_event,script_values=script_window.read()
        if script_event in ("Exit",sg.WIN_CLOSED):
            break
# -----main event loop-----#
while True:
    event, _ = window.read()
    if (event in (sg.WIN_CLOSED, "Exit")):
        s.write(bytes('I' + '\n', 'ascii'))
        time.sleep(0.25)  # Delay for accurate read/write operations
        s.reset_output_buffer()
        break
    if (event == "calibaration"):
        open_calibration_window()
    if (event=="Joystick Controled Rotation"):
        opem_JoystickRotation_window()
    if (event=="Joystick Painter"):
        open_canvas()
    if (event=="Script"):
        open_script_mode()
window.close()

