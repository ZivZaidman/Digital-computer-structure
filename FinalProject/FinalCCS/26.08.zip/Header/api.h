#ifndef _api_H_
#define _api_H_

#include  "../header/halGPIO.h"     // private library - HAL layer
extern void clockwiseRotation();
extern int Vy_Vx[2];
extern int division();
extern unsigned int divisionBy128();
extern void counterclockwiseRotation();
#endif
