#include  "../header/api.h"         // private library - API layer
#include  "../header/halGPIO.h"     // private library - HAL layer
#include "stdio.h"

enum Motorstate stepState;
int angle=0;
int32_t temp_division=0;
unsigned int amount_of_steps =0;
int CalibAngles=0;
int clockDIR=0;

//-------------------calibrate stepmotor-----------------//
void clibrateMotor(){
    switch (stepState){
      case Idlestep:
          __bis_SR_register(LPM0_bits + GIE);       // wait for command from SW
          break;
      case Rotate:
          rotationCounter=0;
          while(rotateFlag){
              rotationCounter++;
              clockwiseRotation();
              TIMERA0_delay_ms(1000);
          }
          break;
      case StopRotate:
          IE2 |= UCA0TXIE; // Disable USCI_A0 TX interrupt to stop further transmissions
          UCA0TXBUF=rotationCounter;
          CalibAngles=divisionBy128(rotationCounter*90);//division

          break;
    }
}
//-------------------change angle according to joystick-----------------//
void Joystickcontroledangle(){
    MessurejoystickV ();//calcullates the position of X and Y
    int Vrx = Vy_Vx[1] - 512;
    int Vry = Vy_Vx[0] - 512;
    angle=tangens(Vry,Vrx);
    amount_of_steps =divisionBy128(angle*182);//(angle*512)/360=Number of steps=~(angle*182)/128
    if (amount_of_steps>=256){
        amount_of_steps = 512-amount_of_steps;
        clockDIR = 1;
    }
    int i;
    for (i=0;i<amount_of_steps;i++){
        if (clockDIR == 1){
            counterclockwiseRotation();
            TIMERA0_delay_ms(1000);
        }else{
            clockwiseRotation();
            TIMERA0_delay_ms(1000);
        }

    }
    clockDIR=0;
    state=Idle;


}
//-------------------------------------------------------------
//                JoyStickADC_Steppermotor
//-------------------------------------------------------------
void MessurejoystickV (){
    ADC10CTL0 &= ~ENC;
    while (ADC10CTL1 & ADC10BUSY);               // Wait if ADC10 core is active
    ADC10SA = &Vy_Vx;                        // Data buffer start
    ADC10CTL0 |= ENC + ADC10SC; // Sampling and conversion start
    __bis_SR_register(LPM0_bits + GIE);        // LPM0, ADC10_ISR will force exit
    ADC10CTL0 &= ~ENC;
}
