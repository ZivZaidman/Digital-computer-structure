import PySimpleGUI as sg
import serial as ser
import sys, glob
import time
import serial.tools.list_ports
from tkinter import *
from tkinter.colorchooser import askcolor
import mouse
import os
from os import path
import threading
import binascii
import pyautogui
#---------------GUI definition--------------#
#----Main window-----#
sg.theme('DarkGrey9')
layout=[[sg.Button("calibaration", size=(30,4),button_color=("white", "green"), font=("Helvetica", 14))
            , sg.Button("Joystick Controled Rotation", size=(30,4),button_color=("white", "green"), font=("Helvetica", 14))],
        [sg.Button("Joystick Painter", size=(30,4),button_color=("white", "green"), font=("Helvetica", 14))
            ,sg.Button("Script",size=(30,4),button_color=("white", "green"), font=("Helvetica", 14))],
        [sg.Exit(size=(61,2),button_color=("white", "darkred"), font=("Helvetica", 14))]]

window = sg.Window("Final project Menu", layout)
#-----UARTconfig-----#
s = ser.Serial('COM5', baudrate=9600, bytesize=ser.EIGHTBITS,
               parity=ser.PARITY_NONE, stopbits=ser.STOPBITS_ONE,
               timeout=1)  # timeout of 1 sec so that the read and write operations are blocking,
# when the timeout expires the program will continue
# clear buffers
s.reset_input_buffer()
s.reset_output_buffer()
#----Calibration window-----#
RotationCounter=0
degreesCounter=RotationCounter*0.088
def open_calibration_window():
    s.write(bytes('C' + '\n', 'ascii'))
    time.sleep(0.25)  # Delay for accurate read/write operations
    s.reset_output_buffer()
    while True:
        while s.in_waiting == 0:
            None
        received_data = s.read_until(expected=b'\n')
        received_int = int.from_bytes(received_data,byteorder='little')
        s.reset_input_buffer()
        #    time.sleep(0.25)  # Delay for accurate read/write operations
        #if s.in_waiting > 0:
        while s.in_waiting == 0:
            None
        received_data = s.read_until(expected=b'\n')
        received_int=received_int+int.from_bytes(received_data,byteorder='little')*(16^2)
        s.reset_input_buffer()
        #    time.sleep(0.25)  # Delay for accurate read/write operations
        #if s.in_waiting > 0:
        while s.in_waiting == 0:
            None
        received_data = s.read_until(expected=b'\n')
        degreesCounter=int.from_bytes(received_data,byteorder='little')
        s.reset_input_buffer()
     #   time.sleep(0.25)  # Delay for accurate read/write operations
        break
            # Process the received data here
    calibration_layout = [[sg.Text("Rotations Counter:"), sg.Text(received_int)],
                          [[sg.Text("degrees:"), sg.Text(degreesCounter)]],
                          [sg.Exit(size=(15, 2), button_color=("white", "green"), font=("Helvetica", 14))]]

    calibration_window = sg.Window("Calibaration", calibration_layout)

    while True:
        calibration_event, _ = calibration_window.read()
        if (calibration_event in (sg.WIN_CLOSED, "Exit")):
            s.write(bytes('I' + '\n', 'ascii'))
            time.sleep(0.25)  # Delay for accurate read/write operations
            s.reset_output_buffer()
            break
    calibration_window.close()
def opem_JoystickRotation_window():
    s.write(bytes('J' + '\n', 'ascii'))
    time.sleep(0.25)  # Delay for accurate read/write operations
    s.reset_output_buffer()
    joystickRotation_layout = [[sg.Text("Use your Joystick to rotate the stepmotor")],
                          [sg.Exit(size=(15, 2), button_color=("white", "green"), font=("Helvetica", 14))]]
    joystickRotation_window=sg.Window("joystickRotation",joystickRotation_layout)
    while True:
        joystickRotation_event,_=joystickRotation_window.read()
        if (joystickRotation_event in (sg.WIN_CLOSED, "Exit")):
            s.write(bytes('I' + '\n', 'ascii'))
            time.sleep(0.25)  # Delay for accurate read/write operations
            s.reset_output_buffer()
            break
    joystickRotation_window.close()
"""def open_canvas():
    s.write(bytes('P' + '\n', 'ascii'))
    time.sleep(0.25)  # Delay for accurate read/write operations
    s.reset_output_buffer()
    Canvas_layout=[[sg.Graph(
        canvas_size=(600, 600),
        graph_bottom_left=(0, 0),
        graph_top_right=(600,600),
        background_color='white',
        key='-GRAPH-'
    )],
    [sg.Button('Clear', size=(10, 1),button_color=("white", "green"), font=("Helvetica", 14)),
     sg.Button('Exit', size=(10, 1),button_color=("white", "green"), font=("Helvetica", 14))]
    ]
    painter_window=sg.Window('joystick Painter',Canvas_layout, finalize=True)
    graph = painter_window['-GRAPH-']
    last_position = None
    #drawing = False
    while True:
        painter_event,values=painter_window.read()

        if painter_event in (sg.WIN_CLOSED, "Exit"):
            s.write(bytes('I' + '\n', 'ascii'))
            time.sleep(0.25)  # Delay for accurate read/write operations
            s.reset_output_buffer()
            break

        if painter_event == 'Clear':
            graph.Erase()  # Clear the canvas
            last_position=None

        if painter_event == '-GRAPH-':
            mouse = values['-GRAPH-']
            # Start drawing when the mouse is pressed
            if mouse and last_position:  # If there's a previous position, draw a line
                graph.DrawLine(last_position, mouse, width=20, color='black')

            last_position = mouse  # Update the last position
    painter_window.close()

           if not drawing and mouse:
                last_position = mouse
                drawing = True

            # Draw while the mouse is being dragged
            if drawing and mouse:
                if last_position:
                    graph.DrawLine(last_position, mouse, width=2, color='black')
                last_position = mouse

        if painter_event.endswith('+UP'):  # When mouse button is released
            drawing = False
            last_position = None"""
def open_canvas():
    s.write(bytes('P' + '\n', 'ascii'))
    time.sleep(0.25)  # Delay for accurate read/write operations
    s.reset_output_buffer()
    modes = ['Draw', 'Erase', 'Hover']  # Available modes
    current_mode_index = 0  # Start with 'Draw' mode
    Canvas_layout = [
        [sg.Graph(
            canvas_size=(600, 600),
            graph_bottom_left=(0, 0),
            graph_top_right=(600, 600),
            background_color='white',
            key='-GRAPH-',
            change_submits=True,  # Submit events on changes (like clicks)
            drag_submits=False,  # Don't submit drag events
        )],
        [sg.Text(f'Mode: {modes[current_mode_index]}',key='mode_text'),
         sg.Button('Clear', size=(10, 1), button_color=("white", "green")),
         sg.Button('Exit', size=(10, 1), button_color=("white", "green"))]
    ]

    painter_window = sg.Window('Joystick Painter', Canvas_layout, finalize=True)
    graph = painter_window['-GRAPH-']
    tk_canvas = graph.Widget
    prev_pos = None
    hover_item=None
    def change_mode():
        nonlocal current_mode_index, prev_pos, hover_item
        current_mode_index = (current_mode_index + 1) % len(modes)
        painter_window['mode_text'].update(f'Mode: {modes[current_mode_index]}')
        prev_pos=None
        if hover_item:
            graph.delete_figure(hover_item)
            hover_item = None
    while True:
        painter_event, values = painter_window.read(timeout=10)

        if painter_event in (sg.WIN_CLOSED, "Exit"):
            s.write(bytes('I' + '\n', 'ascii'))
            time.sleep(0.25)  # Delay for accurate read/write operations
            s.reset_output_buffer()
            break
        if s.in_waiting>0:
            joysstick_ISR=s.read()
            if joysstick_ISR==b'\x99':
                change_mode()
    painter_window.close()

def open_script_mode():
    script_layout=[[sg.Text("Choose a flie:"),sg.Input(key="IN"),sg.FileBrowse(button_color=("white", "green"))],
                   [sg.Button("Exit",button_color=("white", "darkred")),sg.Button("upload File",button_color=("white", "green"))]]
    script_window=sg.Window("Uploading a File to the MSP430", script_layout)
    while True:
        script_event,script_values=script_window.read()
        if script_event in ("Exit",sg.WIN_CLOSED):
            break
# -----main event loop-----#
while True:
    event, _ = window.read()
    if (event in (sg.WIN_CLOSED, "Exit")):
        s.write(bytes('I' + '\n', 'ascii'))
        time.sleep(0.25)  # Delay for accurate read/write operations
        s.reset_output_buffer()
        break
    if (event == "calibaration"):
        open_calibration_window()
    if (event=="Joystick Controled Rotation"):
        opem_JoystickRotation_window()
    if (event=="Joystick Painter"):
        open_canvas()
    if (event=="Script"):
        open_script_mode()
window.close()

