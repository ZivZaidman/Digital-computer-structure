import PySimpleGUI as sg
import serial as ser
import sys, glob
import time
import serial.tools.list_ports
from tkinter import *
from tkinter.colorchooser import askcolor
import mouse
import os
from os import path
import threading
import binascii
import math
import pyautogui
#---------------GUI definition--------------#
#----Main window-----#
sg.theme('DarkGrey9')
layout=[[sg.Button("calibaration", size=(30,4),button_color=("white", "green"), font=("Helvetica", 14))
            , sg.Button("Joystick Controled Rotation", size=(30,4),button_color=("white", "green"), font=("Helvetica", 14))],
        [sg.Button("Joystick Painter", size=(30,4),button_color=("white", "green"), font=("Helvetica", 14))
            ,sg.Button("Script",size=(30,4),button_color=("white", "green"), font=("Helvetica", 14))],
        [sg.Exit(size=(61,2),button_color=("white", "darkred"), font=("Helvetica", 14))]]

window = sg.Window("Final project Menu", layout)
#-----UARTconfig-----#
s = ser.Serial('COM5', baudrate=9600, bytesize=ser.EIGHTBITS,
               parity=ser.PARITY_NONE, stopbits=ser.STOPBITS_ONE,
               timeout=1)  # timeout of 1 sec so that the read and write operations are blocking,
# when the timeout expires the program will continue
# clear buffers
s.reset_input_buffer()
s.reset_output_buffer()
#----Calibration window-----#
RotationCounter=0
degreesCounter=0
def open_calibration_window(i=None):
    s.reset_input_buffer()
    s.write(bytes('C' + '\n', 'ascii'))
    time.sleep(0.25)  # Delay for accurate read/write operations
    s.reset_output_buffer()
    received_int = [0,0,0,0,0]
    i=0
    while(i<5):
        if s.in_waiting > 0:
            received_data = s.read(1)
            received_int[i] = int.from_bytes(received_data, byteorder='little')
            print("received_data: ", received_data)
            print("received_int: ", received_int)
            s.reset_input_buffer()
            i+=1
        number_of_rotations = int(''.join(map(str, received_int)))
    i=0
    while (i < 5):
        if s.in_waiting > 0:
            received_data = s.read(1)
            received_int[i] = int.from_bytes(received_data, byteorder='little')
            print("received_data: ", received_data)
            print("received_int: ", received_int)
            s.reset_input_buffer()
            i += 1
        degreesCounter = int(''.join(map(str, received_int)))
    """while True:
        if s.in_waiting>0:
            received_data = s.read_until(expected=b'\n')
            #received_data = s.readline()
            received_int=int.from_bytes(received_data,byteorder='little')*(256)
            print("received_data: ", received_data)
            print("received_int: ",received_int)
            s.reset_input_buffer()
            break
    while True:
        if s.in_waiting>0:
            received_data = s.read_until(expected=b'\n')
            received_int=received_int+int.from_bytes(received_data,byteorder='little')
            print("received_data2: ", received_data)
            print("received_int2: ",received_int)
            s.reset_input_buffer()
            break"""
            #    time.sleep(0.25)  # Delay for accurate read/write operations
            #if s.in_waiting > 0:
    """while True:
        if s.in_waiting>0:
            received_data = s.read_until(expected=b'\n')
            degreesCounter=int.from_bytes(received_data,byteorder='little')
            s.reset_input_buffer()
            print("degreesCounter",degreesCounter)
            break"""
     #   time.sleep(0.25)  # Delay for accurate read/write operations
            # Process the received data here
    calibration_layout = [[sg.Text("Rotations Counter:"), sg.Text(number_of_rotations)],
                          [[sg.Text("degrees:"), sg.Text(degreesCounter)]],
                          [sg.Exit(size=(15, 2), button_color=("white", "green"), font=("Helvetica", 14))]]

    calibration_window = sg.Window("Calibaration", calibration_layout)

    while True:
        calibration_event, _ = calibration_window.read()
        if (calibration_event in (sg.WIN_CLOSED, "Exit")):
            s.write(bytes('I' + '\n', 'ascii'))
            time.sleep(0.25)  # Delay for accurate read/write operations
            s.reset_output_buffer()
            break
    calibration_window.close()
def opem_JoystickRotation_window():
    s.write(bytes('J' + '\n', 'ascii'))
    time.sleep(0.25)  # Delay for accurate read/write operations
    s.reset_output_buffer()
    joystickRotation_layout = [[sg.Text("Use your Joystick to rotate the stepmotor")],
                          [sg.Exit(size=(15, 2), button_color=("white", "green"), font=("Helvetica", 14))]]
    joystickRotation_window=sg.Window("joystickRotation",joystickRotation_layout)
    while True:
        joystickRotation_event,_=joystickRotation_window.read()
        if (joystickRotation_event in (sg.WIN_CLOSED, "Exit")):
            s.write(bytes('I' + '\n', 'ascii'))
            time.sleep(0.25)  # Delay for accurate read/write operations
            s.reset_output_buffer()
            break
    joystickRotation_window.close()
#################################################################################################3
import PySimpleGUI as sg
import mouse
import time
import math

def open_canvas():
    s.reset_input_buffer()
    s.write(bytes('P' + '\n', 'ascii'))
    time.sleep(0.25)  # Delay for accurate read/write operations
    s.reset_output_buffer()
    print('P')
    # Initial settings
    #print("Hello world")
    canvas_size = (500, 500)  # Define the size of the canvas
    draw_color = 'black'       # Color for drawing
    erase_color = 'white'      # Color for erasing (background color)
    hover_color = 'red'        # Color for hover effect
    modes = ['Draw', 'Erase', 'Hover']  # Available modes
    current_mode_index = 0  # Start with 'Draw' mode

    # Define the layout of the window
    layout = [
        [sg.Graph(
            canvas_size,            # Size of the canvas
            (0, 0),                 # Lower left corner coordinates
            canvas_size,            # Upper right corner coordinates
            key='canvas',           # Key to reference the canvas
            change_submits=True,    # Submit events on changes (like clicks)
            drag_submits=False,     # Don't submit drag events
            background_color='white'  # Background color of the canvas
        )],
        [sg.Text(
            f'Mode: {modes[current_mode_index]}',  # Display current mode
            key='mode_text',                        # Key to update the text
            font=('Helvetica', 14)                  # Font styling
        )],
        [sg.Button("draw circle"),sg.Button("draw squere")]
    ]

    # Create the PySimpleGUI painter_window
    painter_window = sg.Window('PySimpleGUI Painter', layout, finalize=True)
    canvas = painter_window['canvas']  # Get the canvas element

    # Access the underlying Tkinter Canvas for advanced event handling
    tk_canvas = canvas.Widget

    # Variables to keep track of previous positions and hover items
    prev_pos = None      # Previous mouse position for drawing lines
    neutral_item = None    # Current hover circle (if any)
    erase_item=None
    angle=0;
    def get_angle():
        nonlocal angle
        i = 0
        received_angle = [0, 0, 0, 0, 0]
        s.write(bytes('A' + '\n', 'ascii'))
        print("A")
        time.sleep(0.25)
        s.reset_output_buffer()  # send ACK, wait for angle and than move acordingly

        while (i < 5):
            # print(i)
            if s.in_waiting > 0:
                received_data = s.read(1)
                received_angle[i] = int.from_bytes(received_data, byteorder='little')
                if received_angle[i] == 0x99:
                    print("angle 0x99")
                    return int(0x99)
                s.reset_input_buffer()
                i += 1
        return int(''.join(map(str, received_angle)))

    def calculate_xy(angle,radius=10):

        radian = math.radians(angle)
        # Calculate new x and y positions using polar coordinates
        x = radius * math.cos(radian)
        y = radius * math.sin(radian)
        return int(x), int(y)

    # Define the motion event handler
    def motion_event(event):
        nonlocal current_mode_index, prev_pos, neutral_item, erase_item

        # Get mouse position within the canvas
        """x = event[0]
        y = canvas_size[1] - event[1]  # Invert y-axis to match Graph coordinates
        """
        x = event.x
        y = canvas_size[1] - event.y  # Invert y-axis to match Graph coordinates

        # Check if the mouse is within the canvas boundaries
        if 0 <= x <= canvas_size[0] and 0 <= y <= canvas_size[1]:
            current_mode = modes[current_mode_index]

            if current_mode == 'Draw':
                if prev_pos:
                    # Draw a line from the previous position to the current position
                    canvas.draw_line(prev_pos, (x, y), color=draw_color, width=2)
                # Update the previous position
                prev_pos = (x, y)

            elif current_mode == 'Erase':
                if prev_pos:
                    # Erase by drawing a thick white line
                    canvas.draw_line(prev_pos, (x, y), color=erase_color, width=20)
                if erase_item:
                    canvas.delete_figure(erase_item)
                # Draw a new hover circle at the current position
                erase_item = canvas.draw_circle(
                    (x, y),
                    radius=10,
                    fill_color=erase_color,
                    line_color='black'
                )
                # Update the previous position
                prev_pos = (x, y)

            elif current_mode == 'Hover':
                # Remove the previous hover circle to avoid clutter
                if neutral_item:
                    canvas.delete_figure(neutral_item)
                # Draw a new hover circle at the current position
                neutral_item = canvas.draw_circle(
                    (x, y),
                    radius=10,
                    fill_color=hover_color,
                    line_color=hover_color
                )

    """    # Define the click event handler for mode switching
    def click_event(event):
        nonlocal current_mode_index, prev_pos, neutral_item
        # Cycle through the modes
        current_mode_index = (current_mode_index + 1) % len(modes)
        # Update the mode display text
        window['mode_text'].update(f'Mode: {modes[current_mode_index]}')
        # Reset tracking variables
        prev_pos = None
        # Remove any existing hover circle when switching modes
        if erase_item:
            canvas.delete_figure(erase_item)
            erase_item= None
        if neutral_item:
            canvas.delete_figure(neutral_item)
            neutral_item = None"""

    def change_mode(event):
        nonlocal current_mode_index, prev_pos, neutral_item

        current_mode_index = (current_mode_index + 1) % len(modes)
        painter_window['mode_text'].update(f'Mode: {modes[current_mode_index]}')
        prev_pos=(0,0)
        if neutral_item:
            canvas.delete_figure(neutral_item)
            neutral_item = None


    def draw_square(size):
        # Convert screen coordinates to canvas-relative coordinates
        for dx, dy in [(size, 0), (0, size), (-size, 0), (0, -size)]:
            mouse.move(dx, dy, absolute=False, duration=0.2)
            x_canvas = tk_canvas.winfo_pointerx() - tk_canvas.winfo_rootx()
            y_canvas = tk_canvas.winfo_pointery() - tk_canvas.winfo_rooty()
            tk_canvas.event_generate('<Motion>', x=x_canvas, y=y_canvas)

    def draw_circle(radius):
        for i in range(0, 360, 5):
            angle = math.radians(i)
            x = radius * math.cos(angle)
            y = radius * math.sin(angle)
            mouse.move(x, y, absolute=False, duration=0.01)
            x_canvas = tk_canvas.winfo_pointerx() - tk_canvas.winfo_rootx()
            y_canvas = tk_canvas.winfo_pointery() - tk_canvas.winfo_rooty()
            tk_canvas.event_generate('<Motion>', x=x_canvas, y=y_canvas)

        # release the left mouse button
        #mouse.release()
    # Bind the motion and click events to the Tkinter Canvas
    tk_canvas.bind('<Motion>', motion_event)      # Bind mouse movement
    tk_canvas.bind('<Button-1>', change_mode)     # Bind left mouse button click
    x=0
    y=0
    # Event loop to keep the window active
    while True:
        event, values = painter_window.read(timeout=100)  # Read events with a timeout

        if event == sg.WIN_CLOSED:
            break  # Exit the loop if the window is closed
        if event == "draw circle":
            time.sleep(1)
            draw_circle(10)
        if event== "draw squere":
            time.sleep(1)
            draw_square(100)
            #draw_square(100)
        if s.in_waiting>0:
            joysstick_ISR=s.read(1)
            print("joysstick_ISR",joysstick_ISR)
            if joysstick_ISR == b'\x99':
                tk_canvas.event_generate('<Button-1>')
            if joysstick_ISR == b'\x11':#recived REQ
                angle= get_angle()
                if angle==0x99:
                    tk_canvas.event_generate('<Button-1>')
                    continue
                print(angle)
                (x, y)=calculate_xy(angle)
                mouse.move(x, y, absolute=False, duration=0.2)
                x_canvas = tk_canvas.winfo_pointerx() - tk_canvas.winfo_rootx()
                y_canvas = tk_canvas.winfo_pointery() - tk_canvas.winfo_rooty()
                tk_canvas.event_generate('<Motion>', x=x_canvas, y=y_canvas)

    painter_window.close()  # Close the window gracefully

import pyautogui
import math

"""def move_in_angle(angle_degrees, step_size=1):
    angle_radians = math.radians(angle_degrees)

    delta_x = step_size * math.cos(angle_radians)
    delta_y = step_size * math.sin(angle_radians)

    sg.moveRel(delta_x, delta_y)"""
#######################################################################################################################################################################################################################3
def open_script_mode():
    script_layout=[[sg.Text("Choose a flie:"),sg.Input(key="IN"),sg.FileBrowse(button_color=("white", "green"))],
                   [sg.Button("Exit",button_color=("white", "darkred")),sg.Button("upload File",button_color=("white", "green"))]]
    script_window=sg.Window("Uploading a File to the MSP430", script_layout)
    while True:
        script_event,script_values=script_window.read()
        if script_event in ("Exit",sg.WIN_CLOSED):
            s.write(bytes('I' + '\n', 'ascii'))
            time.sleep(0.25)  # Delay for accurate read/write operations
            s.reset_output_buffer()
            break
        if script_event == "upload File":
            file_path=script_values("IN")            # save file path

    script_window.close()

    def convertfile(file_path): #####convert python comand a file to op code of hanan

        with open(file_path, 'rb') as f:
            FileContent=f.read()
        op_codes_dict={
            'inc_lcd'       :   '01',
            'dec_lcd'       :   '02',
            'rra_lcd'       :   '03',
            'set_delay'     :   '04',
            'clear_all_leds':   '05',
            'stepper_deg'   :   '06',
            'stepper_scan'  :   '07',
            'sleep'         :   '08',
        }
        converted_lines=[]
        data=FileContent.decode('utfa-8').strip()       #raw data decoded from ascii
        lines=data.split('\r\n')                        #raw data split into lines
        for line in lines:                              #find all comands, iterrations for each line
            line_part=line.split()
            comand=line_part[0]                         #command will be first

            if comand in op_codes_dict:
                op_code=op_codes_dict[comand]           #this is the translated op code for this line
                #now we will check for parts:
                if len(line_part)>1:
                    iter=line_part[1]
                    if ',' in iter:                     #there is more than one iteration data
                        iter_val=iter.split(',')
                        formatted_iter = ''.join([f'{int(d):02X}' for d in iter_val])
                    else:                               #only one iteration
                        formatted_iter = f'{int(iter):02X}'
                converted_line = op_code + formatted_iter
            else:
                converted_line = op_code
            converted_lines.append(converted_line)                  #


        # Write the translated lines to a new file
        converted_file_path = 'coverted_file.txt'
        with open(converted_file_path, 'w') as f:
            for line in converted_lines:
                f.write(line + '\n')

        return converted_file_path  # Return the file path instead of the file object


# -----main event loop-----#
while True:
    event, _ = window.read()
    if (event in (sg.WIN_CLOSED, "Exit")):
        s.write(bytes('I' + '\n', 'ascii'))
        time.sleep(0.25)  # Delay for accurate read/write operations
        s.reset_output_buffer()
        break
    if (event == "calibaration"):
        open_calibration_window()
    if (event=="Joystick Controled Rotation"):
        opem_JoystickRotation_window()
    if (event=="Joystick Painter"):
        open_canvas()
    if (event=="Script"):
        open_script_mode()
window.close()

