#ifndef _api_H_
#define _api_H_

#include  "../header/halGPIO.h"     // private library - HAL layer
extern void clockwiseRotation();
extern int Vy_Vx[2];
extern int division();
extern unsigned int divisionBy128();
extern void counterclockwiseRotation();
extern char printarray[5];
extern void joystick_painter();
extern int ack;
extern int d;
#endif
