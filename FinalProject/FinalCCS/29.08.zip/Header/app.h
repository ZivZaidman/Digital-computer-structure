#ifndef _app_H_
#define _app_H_

enum FSMstate{Idle,calibration,JoystickRotation,Painter,state4,state5,state6,state7,state8,state9}; // global variable
enum Motorstate{Idlestep,Rotate, StopRotate, JRcontrol};
enum StatusReceive{Name,Size,Content};
enum SYSmode{mode0,mode1,mode2,mode3,mode4}; // global variable
extern int ack;

#endif
