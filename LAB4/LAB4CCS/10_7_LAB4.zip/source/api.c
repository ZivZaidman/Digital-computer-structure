#include  "../header/api.h"         // private library - API layer
#include  "../header/halGPIO.h"     // private library - HAL layer
#include "stdio.h"

int lcd_counter=0;
//---------------------------------------------------
//              state1 Function
//---------------------------------------------------
void state1Func(){

}
//---------------------------------------------------
//              state2 Function - Seconds Counter
//---------------------------------------------------
void state2Func(){
    while (state==state2){
        lcd_cmd(0x01);
        if (lcd_counter<=9){
            lcd_data(lcd_counter+0x30);
        }else if (lcd_counter<=99){
            lcd_data(lcd_counter/10+0x30);
            lcd_data(lcd_counter%10+0x30);
        }else if (lcd_counter<=999){
            lcd_data(lcd_counter/100+0x30);
            lcd_data((lcd_counter/10)%10+0x30);
            lcd_data(lcd_counter%10+0x30);
        }else if (lcd_counter<=9999){
            lcd_data(lcd_counter/1000+0x30);
            lcd_data((lcd_counter/100)%10+0x30);
            lcd_data((lcd_counter/10)%10+0x30);
            lcd_data(lcd_counter%10+0x30);
        }else if (lcd_counter>=10000){
            lcd_counter=0;
        }

        lcd_counter++;
        startTimer0A0(x);
        __bis_SR_register(LPM0_bits+GIE);
    }
}

//---------------------------------------------------
//              state3 Function - LED printing using DMA
//---------------------------------------------------
void state3Func(){

    }


//-----------------------------------------------------
//              state4
//----------------------------------------------------
void state4Func(){
    lcd_cmd(0x01);


}







